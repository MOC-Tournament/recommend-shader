#version 450 compatibility

#define IS_END

#include "/program/Grade.glsl"
