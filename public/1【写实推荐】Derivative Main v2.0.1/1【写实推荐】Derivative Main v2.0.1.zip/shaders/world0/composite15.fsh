#version 450 compatibility

#define IS_OVERWORLD

#include "/program/Grade.glsl"
