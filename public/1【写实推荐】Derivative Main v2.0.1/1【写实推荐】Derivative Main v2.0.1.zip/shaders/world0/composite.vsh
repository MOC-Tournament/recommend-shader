#version 450 compatibility

out vec2 texcoord;

flat out vec3 colorSunlight;
flat out vec3 colorSkylight;


#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"


void main() {
	gl_Position = vec4(gl_Vertex.xy * 2.0 - 1.0, 0.0, 1.0);
	texcoord = gl_MultiTexCoord0.xy;

	colorSunlight = texelFetch(colortex5, ivec2(screenSize * 0.2 + 1), 0).rgb;
	colorSkylight = texelFetch(colortex5, ivec2(screenSize * 0.2 + 2), 0).rgb;
}
