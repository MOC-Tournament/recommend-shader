#version 450 compatibility

#include "/program/RenderSkybox.glsl"
