#version 450 compatibility

#include "/program/DownSample0.glsl"
