#version 450 compatibility

void main() {
    discard;
}

/* DRAWBUFFERS:5 */