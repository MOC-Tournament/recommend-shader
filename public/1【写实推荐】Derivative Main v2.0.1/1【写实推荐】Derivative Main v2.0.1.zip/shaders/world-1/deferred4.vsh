#version 450 compatibility

out vec2 texcoord;

flat out vec3 colorTorchlight;

#include "/lib/Head/Common.inc"

void main() {
	gl_Position = vec4(gl_Vertex.xy * 2.0 - 1.0, 0.0, 1.0);
	texcoord = gl_MultiTexCoord0.xy;

	colorTorchlight = Blackbody(float(TORCHLIGHT_COLOR_TEMPERATURE));
}
