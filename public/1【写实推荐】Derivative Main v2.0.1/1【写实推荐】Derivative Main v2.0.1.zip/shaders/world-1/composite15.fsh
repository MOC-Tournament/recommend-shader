#version 450 compatibility

#define IS_NETHER

#include "/program/Grade.glsl"
