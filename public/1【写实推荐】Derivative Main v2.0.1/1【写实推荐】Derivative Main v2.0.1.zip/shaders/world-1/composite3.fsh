#version 450 compatibility

#include "/program/Temporal.frag"
