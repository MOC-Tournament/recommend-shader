#version 450 compatibility

#include "/program/SpatialFilter.glsl"
