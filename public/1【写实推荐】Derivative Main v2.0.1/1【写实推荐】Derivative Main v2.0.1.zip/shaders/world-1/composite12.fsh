#version 450 compatibility

#include "/program/BlurH.glsl"
